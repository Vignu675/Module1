package service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import bean.Account;
import bean.TransactionDetails;
import dao.CustomerDao;

public class CustomerService {
		
		CustomerDao cdobj=new CustomerDao();
		TransactionDetails transaction = new TransactionDetails();
		Account account = new Account();
		//CustomerDao data = new CustomerDao();
		
		public void serviceStoreCustomer(Account aobj )
		{
			cdobj.daoStoreCustomer(aobj);
		}
		
		public Account serviceRetrieveCustomer(long accNo){
			return cdobj.daoRetrieveCustomer(accNo);
		}

		public HashMap<Long, Account> serviceRetrieveCollection() {
		
			return cdobj.daoRetrieveCustomer();
		}

	
		public void createTransactionAccount() {
			transaction.setAccountNumber(account.getAccNo());
			transaction.setCredit(account.getBalance());
			transaction.setDebit(0);
			transaction.setAmount(account.getBalance());
			cdobj.setTransactionList(transaction);
			
		}

		public void depositTransactions(double deposite) {
			transaction.setAccountNumber(account.getAccNo());
			transaction.setCredit(deposite);
			transaction.setDebit(0);
			transaction.setAmount(account.getBalance());
			cdobj.setTransactionList(transaction);
			
		}
		
		public void withdrawTransactions(double withdrawAmount) {
			transaction.setAccountNumber(account.getAccNo());
			transaction.setCredit(0);
			transaction.setDebit(withdrawAmount);
			transaction.setAmount(account.getBalance());
			cdobj.setTransactionList(transaction);
			
		}
		
		public List<TransactionDetails> getTransactionDetails(long accountNumber) {
			List<TransactionDetails> transactionList = cdobj.getTransactionList();
			List<TransactionDetails> transactionList2 = new ArrayList<>();
			for (TransactionDetails transactionDetail : transactionList) {
				if (accountNumber == transactionDetail.getAccountNumber()) {
					transactionList2.add(transactionDetail);
				}
			}
			return transactionList2;
		}

		

	
}
