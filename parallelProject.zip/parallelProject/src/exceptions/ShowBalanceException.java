package exceptions;

@SuppressWarnings("serial")
public class ShowBalanceException extends Exception {
    public ShowBalanceException(String s)
    {
        System.out.println(s);
    }
}