package exceptions;

public class FundTransferException extends Exception {
	public FundTransferException(String s)
    {
        System.out.println(s);
    }
}
