package ui;
import ui.AccountUI;
import java.util.Scanner;
public class Main {
	
	public static void main(String[]args){
		AccountUI aui=new AccountUI();
	
		while(true){
		System.out.println("'Enter Your Choice'");
		System.out.println("1. New Account Generation");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit Amount");
		System.out.println("4. WithDraw Amount");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		System.out.println("7. Exit");

		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch (choice) {
		case 1:
		{
			aui.createAccount();
			break;
		}
		case 2:
		{
			aui.showBalance();
			break;
		}
		case 3:
		{
			aui.depositAmount();
			break;
		}
		case 4:
		{
			aui.withdrawAmount();
			break;
		}
		case 5:
		{
			aui.fundTransfer();
			break;
		}
		case 6:
		{
			aui.getTransactionDetails();
			break;
		}
		case 7:
		{
			System.exit(0);
		}
		default :
		{
			continue;
		}
	}
	}
	
}
}
