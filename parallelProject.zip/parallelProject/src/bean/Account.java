package bean;

public class Account {
	static long accNo=123000;
	 static long accNo1=123000;
	 String AccType;
	 public static double balance;
	Customer cobj;
	
	
	
	public Account() {
	
	}
	public Account(String accountType, double balance,Customer cobj) {
		super();
		Account.accNo=getAccNo();
		this.AccType = accountType;
		this.balance = balance;
		this.cobj=cobj;
	}
	public static long getAccNo() {
		accNo++;
		return accNo;
	}
	public long getAccNo1() {
		accNo1++;
		return accNo1;
	}
	public String getAccountType() {
		return AccType;
	}
	public void setAccountType(String accountType) {
		this.AccType = accountType;
	}
	public static double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account Number="+accNo+",\nAccount Type=" + AccType + ",\nAvailable Balance=" + balance + ",\nCustomer Details=" +cobj ;
	} 
}
