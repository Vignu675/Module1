package com.cg.eis.exception;

import java.util.Scanner;

@SuppressWarnings("serial")
public class Exercise6 extends RuntimeException {
	Exercise6()
	{
		System.out.println("Less Salary");
	}
	Exercise6(int n)
	{
		System.out.println("Less Salary");
	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		sc.close();
		try {
		if(a<3000)
			throw new Exercise6();
		}catch(Exception e)
		{
			System.out.println("Can Improve");
		}finally
		{
			System.out.println("All the Best");
		}
		// TODO Auto-generated method stub

	}

}
