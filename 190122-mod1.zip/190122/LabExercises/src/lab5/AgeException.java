package lab5;
import java.util.Scanner;
public class AgeException extends Exception{
	
	public AgeException(String str){
		System.out.println(str);
	}
public static void main(String[]args){
	Scanner sc=new Scanner(System.in);
	int age=sc.nextInt();
	try{
	if(age<15){
		throw new AgeException("Invalid Age");
	}

	else{
		System.out.println("Valid Age");
	}
	}
	catch(AgeException e){
		System.out.println(e);
		}
	}
	
	}

