package lab5;
//import java.util.Scanner;
enum Signals{
	RED,GREEN,YELLOW;
}
public class trafficSignals {
	static Signals color;
	
	public trafficSignals(Signals color){
		this.color=color;
	}
	
	public void signalLight(){
	switch(color){
	case RED:System.out.println("STOP");
	break;
	
	case GREEN:System.out.println("GO");
	break;
	case YELLOW:System.out.println("READY");
	}
	}
	
	
	public static void main (String[]args){
		trafficSignals signal=new trafficSignals(Signals.GREEN);
		signal.signalLight();
		}
	
}
