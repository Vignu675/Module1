package lab8;

import java.util.Scanner;

public class StringCheckOfJobTitle {

	public static void main(String[]args) {
		System.out.println("Enter the name");
		Scanner scanner=new Scanner(System.in);
		String s1=scanner.next();
		scanner.close();
		String s2=s1.substring(0,s1.length()-4);
		if(s1.substring(8,s1.length()).equals("_job") && s2.length()==8)
		{
			System.out.println("True");
		}
		else {
		System.out.println("False");
	}
	}
}
