package lab8;

public class dispCLW {

	public static int words(String s){
		char[] c= s.toCharArray();
		int count=1;
		for(int i=0;i<s.length();i++){
			if(c[i]==' '){
				count++;
			}
		}
			return count;
		
	}
	
	public static void main(String[]args){
		String s=new String("Hello hi bye bye");
		int len=s.length();
		System.out.println("No of characters: " +len);
		System.out.println("No of words:" +words(s));
	}
}
