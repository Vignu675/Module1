package lab8;

import java.io.File;

public class fileState {

	public static void main (String[]args){
		File f=new File("C:\\Users\\temaddul\\Desktop\\hey.txt");
		System.out.println(""+f.getName());
		System.out.println(""+f.canRead());
		System.out.println(""+f.canWrite());
		System.out.println(""+f.exists());
		System.out.println(""+f.length());
	}
}
