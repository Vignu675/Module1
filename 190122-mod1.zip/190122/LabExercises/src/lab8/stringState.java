package lab8;

public class stringState {
	
	public void stringCondition(String str){
		char []ch=str.toCharArray();
		int count=0;
		for(int i=0;i<str.length();i++){
			if(ch[i]<=ch[i+1]){
			}
			else count++;
		}
		if(count==0)
			System.out.println("Its a positive String");
		else System.out.println("Its a negative String");
	}
		public static void main(String []args){
			String str="hello";
			stringState ss=new stringState();
			ss.stringCondition(str);
		}
}
