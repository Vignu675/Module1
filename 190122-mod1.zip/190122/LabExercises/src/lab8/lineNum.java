package lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class lineNum {

	public static void main (String[]args) throws FileNotFoundException{
		int i=0;
		File f=new File("C:\\Users\\temaddul\\Desktop\\hey.txt");
		Scanner inputFile=new Scanner(f);
		while(inputFile.hasNext()){
			String line=inputFile.nextLine();
			i++;
			System.out.print(i	);
			System.out.println(line);
		}
		inputFile.close();
	}
	
	
}
