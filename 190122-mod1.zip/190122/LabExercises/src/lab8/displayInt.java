package lab8;
//import java.util.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class displayInt {

	public static void main(String []args){
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		StringTokenizer st=new StringTokenizer(str);
		int n=0,sum=0;
		while(st.hasMoreElements()){
			String t=(String) st.nextElement();
			//System.out.println(t);
			n=Integer.parseInt(t);
			sum=n+sum;
			System.out.println(n);
		}
		System.out.println();
		System.out.println("sum: "+sum);
		sc.close();
	}
}
