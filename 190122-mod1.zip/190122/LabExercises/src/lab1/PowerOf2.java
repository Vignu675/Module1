package lab1;
import java.util.Scanner;
public class PowerOf2 {
static  boolean checkNumber(int n){
		boolean s;
		while(n%2==0&&n!=1)
		{
			n=n/2;
		}
		if(n==1)
		{
			s=true;
		}
		else
		{
			s=false;
		}
		return s;
	}
 public static void main(String args[]){
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter n value: ");
	 int n=sc.nextInt();
	 sc.close();
	 System.out.println(checkNumber(n));
 }
}
