package lab1;

import java.util.Scanner;

public class IncreasingNumber {
public boolean checkNumber(int number){
	
	while(number>0){
		int a=number%10;
		number=number/10;
		int b=number%10;
		if(a<b){
			return false;
		}
	}
		return true;
	}
	
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter n value");
			int n=sc.nextInt();
			sc.close();
			IncreasingNumber in=new IncreasingNumber();
			System.out.println(in.checkNumber(n));
					
		}
}
