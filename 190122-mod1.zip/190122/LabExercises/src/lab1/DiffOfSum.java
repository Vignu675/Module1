package lab1;
import java.util.Scanner;
public class DiffOfSum {
	static int calculateDifference(int a,int b){
		int z=a-(b*b);
		return z;
		
	}
	static int calculateSumOfSquares(int n){
		int z=0;
		for(int i=1,j=0;i<=n;i++)
		{
			j=i*i;
			z=z+j;
		}
		return z;
	}
  static int calculateSquareOfSum(int n){
	  int y=0;
	  for(int i=1,j=0;i<=n;i++)
	  {
		  j=j+i;
		  int z=j;
		  y=z;
	  }
	  return y;
  }
  public static void main(String args[])
  {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("enter the value of n: ");
	  int n=sc.nextInt();
	  sc.close();
	  int a=calculateSumOfSquares(n);
	  int b=calculateSquareOfSum(n);
	  System.out.println("Result:"+calculateDifference(a,b));
  }
}
