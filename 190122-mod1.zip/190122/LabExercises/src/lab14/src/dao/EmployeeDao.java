package dao;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import bean.Employee;;
public class EmployeeDao
{
	List<Employee> l;
	public void StoreData(Employee Ob)
	{
	    l = new ArrayList<Employee>();
		l.add(Ob);
		System.out.println("Added successfully");
		System.out.println(l);
				
	}
	public void RetrieveData(Employee Ob1)
	{
		
		Iterator<Employee> i=l.iterator();
		while(i.hasNext()) {
			Employee e = i.next();
			if(e.getName() == Ob1.getName())
			{
				if( e.getSalary() ==  Ob1.getSalary())
				{
					System.out.println("Id:"+e.getId()+"salary:"+e.getSalary()+"name:"+e.getName()
					+"Designation:"+e.getDesignation()+ " scheme: "+e.getInsuranceScheme());	
				}
			}			
			else
				System.out.println("Not exist");
		}
		
	}
}
