package lab9;

import java.util.HashMap;
import java.util.Scanner;


class SupportClass{

	public HashMap<Integer, Integer> getSquares(int arr[]) {
		HashMap<Integer, Integer> hcal=new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++) {
			hcal.put(arr[i], arr[i]*arr[i]);
		}
		return hcal;
	}
	
}


public class Exercise3 {
	public static void main(String[]args) {
		System.out.println("Enter the number range: ");
		Scanner scanner=new Scanner(System.in);
		int range=scanner.nextInt();
		int[]arr=new int[range];
		
		for(int i=0;i<range;i++) {
			System.out.println("Value in arr["+i+"]");
			arr[i]=scanner.nextInt();
		}
		scanner.close();
		SupportClass sc=new SupportClass();
		HashMap<Integer,Integer> hmap=sc.getSquares(arr);
		System.out.println(hmap);
	}

}
