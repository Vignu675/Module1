package lab9;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;


class GettingData
{
	//@SuppressWarnings("rawtypes")
	public List getvalues(HashMap h)
	{
		Collection values=h.values();
		List<String> arr=new ArrayList<String>(values);
		Collections.sort(arr);
		return arr;
	}
}
public class Exercise1
{
	
	//@SuppressWarnings("rawtypes")
	public static void main(String args[])
	{
		HashMap<Integer,String> hmap=new HashMap<Integer,String>();
		hmap.put(4,"Vignesh");
		hmap.put(9,"Reddy");
		hmap.put(6,"Adith");
		hmap.put(0,"Jaggu");
		hmap.put(8,"Nari");
		GettingData data=new GettingData();
		System.out.println(hmap);
		List l1=data.getvalues(hmap);
		System.out.println(l1);
	}

}
