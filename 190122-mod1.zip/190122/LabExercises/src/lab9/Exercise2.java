package lab9;

import java.util.Scanner;
import java.util.HashMap;
class HelperClass{
	HashMap countCharacter(char[]c){
		HashMap<Character,Integer> charCount=new HashMap<Character,Integer>();
		for(char a:c) {
			if(charCount.containsKey(a)) {
				charCount.put(a, charCount.get(a)+1);
			}
			else {
				charCount.put(a,1);
			}
		}
		return charCount;
		
	}
	
}
public class Exercise2 {
public static void main(String[]args) {
	System.out.println("Enter a String: ");
	Scanner scanner=new Scanner(System.in);
	String str=scanner.next();
	char[] c=str.toCharArray();
	scanner.close();
	
	HelperClass hc=new HelperClass();
	HashMap<Character,Integer> hmap=hc.countCharacter(c);
	System.out.println(hmap);
}
}
