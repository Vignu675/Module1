package lab10;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class FileProgram {
    public static void main(String args[]) throws IOException 
    {
     try {
         FileInputStream fisObj=new FileInputStream("C:\\Users\\temaddul\\Desktop\\Source.txt");
         FileOutputStream fosObj=new FileOutputStream("C:\\Users\\temaddul\\Desktop\\Destination.txt");
         CopyDataThread ctd=new CopyDataThread(fisObj,fosObj);
         ctd.start();
     }catch(Exception e)
     {
         System.out.println(e);
     }
    }
}