package lab3;
import java.util.Scanner;
import java.util.Arrays;
public class charArr {
	
	public int charLength(char[] a,int n){
		Arrays.sort(a);
        int count = 1;
        int total=0;
        char []b=new char[n];
        b[0]=a[0];
        for (int i = 0; i < n; i++)  
        {
           for(int j=i+1;j<i+2;j++){
        	   while(j!=n){
        	   if(a[i]!=a[j]){
        	   count++;
        	   b[count-1]=a[j];
        	   }
        	   break;
           }   
          }
         
        } 
        System.out.println(b);
        for(int i=0;i<count;i++){
        	 total=0;
        	for(int j=0;j<n;j++){
        	if(b[i]==a[j]){
        		total++;
        }
 	 	   
        }System.out.println((char)b[i]+"-"+total);
        }
        return count; 
	}
	
	public static void main(String []args){
		char a[]={};
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements: ");
		int n=sc.nextInt();
		a=new char[n];
		for(int i=0;i<n;i++){
			System.out.println("Enter value in a["+i+"]");
			a[i]=sc.next().charAt(0);
		}
		sc.close();
	 	   System.out.println(a);

	 	  charArr len=new charArr();
 	   System.out.println(len.charLength(a,n)); 
 	   }
	}

