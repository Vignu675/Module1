package lab3;

public class smallNum {
	static int getSecondSmallest(int []a){
		int p;
		for(int i=0;i<=(a.length-1);i++)
		{
			for(int j=i+1;j<=(a.length-1);j++)
			{
				if(a[i]>=a[j])
				{
					p=a[i];
					a[i]=a[j];
					a[j]=p;
				}
			}
		}
		return a[1];
	}
    public static void main(String args[])
    {
    	int[]a={12,23,56,20};
    	System.out.println("Second smallest number in the array:"+getSecondSmallest(a));
    }
}
