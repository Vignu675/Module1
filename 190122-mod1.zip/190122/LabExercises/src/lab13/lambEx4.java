package lab13;
interface Verify{
    String normal(String str);
}
public class lambEx4 {
    private String name;
    public static String basic(String str) {
        return str;
     }
public static void main(String args[]) {
	lambEx4 obj = new lambEx4();
    obj.setName("siri");
    Verify validate = lambEx4 :: basic;
    System.out.println(validate.normal(obj.getName()));
}
public String getName() {
    return name;
}
public void setName(String name) {
    this.name = name;
}
}