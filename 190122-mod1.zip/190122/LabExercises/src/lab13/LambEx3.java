package lab13;

public class LambEx3 {

}
