package lab13;
import java.util.function.Function;
public  class lambEx5 
{
    public static void main(String[] args)
{
    	lambEx5  fs=new lambEx5 ();
         Function<Integer,Long>f=fs::fact;
         long res=f.apply(3);
         System.out.println(res);
}
    public  long fact(int x)
    {
     long factres=1;
     for(int i=1;i<=x;i++)
     {
         factres=factres*i;
     }
     return factres;
}
}
 









