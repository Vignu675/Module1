package lab13;

import java.util.Scanner;
@FunctionalInterface
interface Power{
	double calPower(double x,double y);
}
public class lambdaEx1 {
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value of x");
		double x=sc.nextInt();
		System.out.println("Enter value of y");
		double y=sc.nextInt(); 
		sc.close();
		Power p=(a,b)->Math.pow(a, b);
		double s=p.calPower(x, y);
		System.out.println(s);
	}
}
