package lab13;

import java.util.Scanner;
@FunctionalInterface
interface Space{
	 public String Gap(String str);
}

public class lambEx2{                           
	
	
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		Space s=(a)->{
			String c="";
			for(int i=0;i<a.length();i++){
				c=c+a.charAt(i)+" ";
			}
			return c;
		};
		
		
		String res=s.Gap(name);
		System.out.println(res);
	}
}
