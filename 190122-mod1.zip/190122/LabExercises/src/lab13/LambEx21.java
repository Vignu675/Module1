package lab13;

import java.util.Scanner;
@FunctionalInterface
interface Gap{
	String space(String a);
}

public class LambEx21 {
		
	
	
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String:" );
		String name=sc.next();
		Gap g=(a)->a.replace("", " ").trim();
		String res=g.space(name);
		System.out.println(res);
		sc.close();
	}
}
