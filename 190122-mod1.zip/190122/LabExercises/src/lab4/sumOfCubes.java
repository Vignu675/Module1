package lab4;
import java.util.Scanner;
public class sumOfCubes {
	
	public int sumCube(int n){
		int z=0;
		while(n>0){
			int p=n%10;
			int q=n/10;
			n=q;
			z=(p*p*p)+z;
		}
		return z;
	}

	
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int n=sc.nextInt();
		sumOfCubes p=new sumOfCubes();
		System.out.println(p.sumCube(n));
		sc.close();
		
	}
}
