--Emp
DROP TABLE EMP;

CREATE TABLE EMP(EMPNO NUMBER(4) NOT NULL,
        ENAME VARCHAR2(10),
        JOB VARCHAR2(9),
        MGR NUMBER(4),
        HIREDATE DATE,
        SAL NUMBER(7, 2),
        COMM NUMBER(7, 2),
        DEPTNO NUMBER(2));

INSERT INTO EMP VALUES
        (7369, 'SMITH',  'CLERK',     7902,
        TO_DATE('17-DEC-1980', 'DD-MON-YYYY'),  800, NULL, 20);
INSERT INTO EMP VALUES
        (7499, 'ALLEN',  'SALESMAN',  7698,
        TO_DATE('20-FEB-1981', 'DD-MON-YYYY'), 1600,  300, 30);
INSERT INTO EMP VALUES
        (7521, 'WARD',   'SALESMAN',  7698,
        TO_DATE('22-FEB-1981', 'DD-MON-YYYY'), 1250,  500, 30);
INSERT INTO EMP VALUES
        (7566, 'JONES',  'MANAGER',   7839,
        TO_DATE('2-APR-1981', 'DD-MON-YYYY'),  2975, NULL, 20);
INSERT INTO EMP VALUES
        (7654, 'MARTIN', 'SALESMAN',  7698,
        TO_DATE('28-SEP-1981', 'DD-MON-YYYY'), 1250, 1400, 30);
INSERT INTO EMP VALUES
        (7698, 'BLAKE',  'MANAGER',   7839,
        TO_DATE('1-MAY-1981', 'DD-MON-YYYY'),  2850, NULL, 30);
INSERT INTO EMP VALUES
        (7782, 'CLARK',  'MANAGER',   7839,
        TO_DATE('9-JUN-1981', 'DD-MON-YYYY'),  2450, NULL, 10);
INSERT INTO EMP VALUES
        (7788, 'SCOTT',  'ANALYST',   7566,
        TO_DATE('09-DEC-1982', 'DD-MON-YYYY'), 3000, NULL, 20);
INSERT INTO EMP VALUES
        (7839, 'KING',   'PRESIDENT', NULL,
        TO_DATE('17-NOV-1981', 'DD-MON-YYYY'), 5000, NULL, 10);
INSERT INTO EMP VALUES
        (7844, 'TURNER', 'SALESMAN',  7698,
        TO_DATE('8-SEP-1981', 'DD-MON-YYYY'),  1500,    0, 30);
INSERT INTO EMP VALUES
        (7876, 'ADAMS',  'CLERK',     7788,
        TO_DATE('12-JAN-1983', 'DD-MON-YYYY'), 1100, NULL, 20);
INSERT INTO EMP VALUES
        (7900, 'JAMES',  'CLERK',     7698,
        TO_DATE('3-DEC-1981', 'DD-MON-YYYY'),   950, NULL, 30);
INSERT INTO EMP VALUES
        (7902, 'FORD',   'ANALYST',   7566,
        TO_DATE('3-DEC-1981', 'DD-MON-YYYY'),  3000, NULL, 20);
INSERT INTO EMP VALUES
        (7934, 'MILLER', 'CLERK',     7782,
        TO_DATE('23-JAN-1982', 'DD-MON-YYYY'), 1300, NULL, 10);

--Designation Masters
DROP TABLE DESIGNATION_MASTER CASCADE CONSTRAINTS;
DROP TABLE DESIGNATION_MASTERs CASCADE CONSTRAINTS;
CREATE TABLE Designation_Master(
Design_Code NUMBER(3) PRIMARY KEY,
Design_Name VARCHAR2(50) UNIQUE);
INSERT INTO designation_master VALUES(101,'HOD');
INSERT INTO designation_master VALUES(102,'Professor');
INSERT INTO designation_master VALUES(103,'Reader');
INSERT INTO designation_master VALUES(104,'Sr.Lecturer');
INSERT INTO designation_master VALUES(105,'Lecturer');
INSERT INTO designation_master VALUES(106,'Director');

--Department Masters
DROP TABLE DEPARTMENT_MASTER CASCADE CONSTRAINTS;
DROP TABLE DEPARTMENT_MASTERs CASCADE CONSTRAINTS;
CREATE TABLE Department_Master(
Dept_code NUMBER(2) PRIMARY KEY,
Dept_Name VARCHAR2(50) UNIQUE);
INSERT INTO department_master VALUES(10,'Computer Science');
INSERT INTO department_master VALUES(20,'Electricals');
INSERT INTO department_master VALUES(30,'Electronics');
INSERT INTO department_master VALUES(40,'Mechanics');
INSERT INTO department_master VALUES(50,'Robotics');

--Student Masters
DROP TABLE STUDENT_MASTER CASCADE CONSTRAINTS;
DROP TABLE STUDENT_MASTERs CASCADE CONSTRAINTS;
CREATE TABLE Student_Master(
Student_Code NUMBER(6) PRIMARY KEY,
Student_Name VARCHAR2(50) NOT NULL,
Dept_Code NUMBER(2) REFERENCES Department_Master(dept_code),
Student_Dob DATE,
Student_Address VARCHAR2(240));

INSERT INTO student_master VALUES(1001,'Amit',10,'11-Jan-80','chennai');
INSERT INTO student_master VALUES(1002,'Ravi',10,'1-Nov-81','New Delhi');
INSERT INTO student_master VALUES(1003,'Ajay',20,'13-Jan-82',null);
INSERT INTO student_master VALUES(1004,'Raj',30,'14-Jan-79','Mumbai');
INSERT INTO student_master VALUES(1005,'Arvind',40,'15-Jan-83','Bangalore');
INSERT INTO student_master VALUES(1006,'Rahul',50,'16-Jan-81','Delhi');
INSERT INTO student_master VALUES(1007,'Mehul',20,'17-Jan-82','Chennai');
INSERT INTO student_master VALUES(1008,'Dev',10,'11-Mar-81','Bangalore');
INSERT INTO student_master VALUES(1009,'Vijay',30,'19-Jan-80','Bangalore');
INSERT INTO student_master VALUES(1010,'Rajat',40,'20-Jan-80','Bangalore');
INSERT INTO student_master VALUES(1011,'Sunder',50,'21-Jan-80','Chennai');
INSERT INTO student_master VALUES(1012,'Rajesh', 30,'22-Jan-80',null);
INSERT INTO student_master VALUES(1013,'Anil',20,'23-Jan-80','Chennai');
INSERT INTO student_master VALUES(1014,'Sunil',10,'15-Feb-85',	null);
INSERT INTO student_master VALUES(1015,'Kapil',40,'18-Mar-81','Mumbai');
INSERT INTO student_master VALUES(1016,'Ashok',40,'26-Nov-80',null);
INSERT INTO student_master VALUES(1017,'Ramesh',30,'27-Dec-80',null);
INSERT INTO student_master VALUES(1018,'Amit Raj',50,'28-Sep-80','New Delhi');
INSERT INTO student_master VALUES(1019,'Ravi Raj',50,'29-May-81','New Delhi');
INSERT INTO student_master VALUES(1020,'Amrit',10,'11-Nov-80',null);
INSERT INTO student_master VALUES(1021,'Sumit',20,'1-Jan-80','Chennai');







--Student Marks
DROP TABLE STUDENT_MARKS CASCADE CONSTRAINTS;
CREATE TABLE Student_Marks(
Student_Code NUMBER (6) REFERENCES student_Master(student_code),
Student_Year NUMBER not null,
Subject1 NUMBER (3),
Subject2 NUMBER (3),
Subject3 NUMBER (3));
INSERT INTO student_marks VALUES(1001,	2010,	55,45,78);
INSERT INTO student_marks VALUES(1002,	2010,	66,74,88);
INSERT INTO student_marks VALUES(1003,	2010,	87,54,65);
INSERT INTO student_marks VALUES(1004,	2010,	65,64,90);
INSERT INTO student_marks VALUES(1005,	2010,	78,88,65);
INSERT INTO student_marks VALUES(1006,	2010,	65,86,54);
INSERT INTO student_marks VALUES(1007,	2010,	67,79,49);
INSERT INTO student_marks VALUES(1008,	2010,	72,55,55);
INSERT INTO student_marks VALUES(1009,	2010,	71,59,58);
INSERT INTO student_marks VALUES(1010,	2010,	68,44,92);
INSERT INTO student_marks VALUES(1011,	2010,	89,96,78);
INSERT INTO student_marks VALUES(1012,	2010,	78,56,55);
INSERT INTO student_marks VALUES(1013,	2010,	75,58,65);
INSERT INTO student_marks VALUES(1014,	2010,	73,74,65);
INSERT INTO student_marks VALUES(1015,	2010,	66,45,74);
INSERT INTO student_marks VALUES(1016,	2010,	68,78,74);
INSERT INTO student_marks VALUES(1017,	2010,	69,44,52);
INSERT INTO student_marks VALUES(1018,	2010,	65,78,56);
INSERT INTO student_marks VALUES(1019,	2010,	78,58,74);
INSERT INTO student_marks VALUES(1020,	2010,	45,55,65);
INSERT INTO student_marks VALUES(1021,	2010,	78,79,78);
INSERT INTO student_marks VALUES(1001,	2011,	68,44,92);
INSERT INTO student_marks VALUES(1002,	2011,	89,96,78);
INSERT INTO student_marks VALUES(1003,	2011,	78,56,55);
INSERT INTO student_marks VALUES(1004,	2011,	75,58,65);
INSERT INTO student_marks VALUES(1005,	2011,	73,74,65);
INSERT INTO student_marks VALUES(1006,	2011,	66,45,74);
INSERT INTO student_marks VALUES(1007,	2011,	68,78,74);
INSERT INTO student_marks VALUES(1008,	2011,	69,44,52);
INSERT INTO student_marks VALUES(1009,	2011,	65,78,56);
INSERT INTO student_marks VALUES(1010,	2011,	78,58,74);
INSERT INTO student_marks VALUES(1011,	2011,	45,55,65);
INSERT INTO student_marks VALUES(1012,	2011,	78,79,78);
INSERT INTO student_marks VALUES(1013,	2011,	66,74,88);
INSERT INTO student_marks VALUES(1014,	2011,	65,64,90);
INSERT INTO student_marks VALUES(1015,	2011,	78,88,65);
INSERT INTO student_marks VALUES(1016,	2011,	65,86,54);
INSERT INTO student_marks VALUES(1017,	2011,	67,79,49);
INSERT INTO student_marks VALUES(1018,	2011,	72,55,55);
INSERT INTO student_marks VALUES(1019,	2011,	71,59,58);
INSERT INTO student_marks VALUES(1020,	2011,	55,45,78);
INSERT INTO student_marks VALUES(1021,	2011,	87,54,65);
--Data to be repeated for 2 more years

--Staff Masters
DROP TABLE STAFF_MASTER CASCADE CONSTRAINTS;
DROP TABLE STAFF_MASTERs CASCADE CONSTRAINTS;
CREATE TABLE staff_Master(
Staff_Code number(8) PRIMARY KEY,
Staff_Name varchar2(50) NOT NULL,
Design_Code REFERENCES Designation_Master(design_code),
Dept_Code REFERENCES Department_Master(dept_code),
Staff_dob DATE,
Hiredate DATE,
Mgr_code NUMBER(8),
Staff_sal NUMBER (10,2),
Staff_address VARCHAR2(240));

INSERT INTO staff_master 
VALUES(100001,'Arvind',102,30,'15-Jan-80','15-Jan-03',100006,17000,'Bangalore');
INSERT INTO staff_master 
VALUES(100002,'Shyam',102,20,'18-Feb-80','17-Feb-02',100007,20000,'Chennai');
INSERT INTO staff_master
VALUES(100003,'Mohan',102,10,'23-Mar-80','19-Jan-02',100006,24000,'Mumbai');
INSERT INTO staff_master 
VALUES(100004,'Anil',102,20,'22-Apr-77','11-Mar-01',100006,20000,'Hyderabad');
INSERT INTO staff_master
VALUES(100005,'John',106,10,'22-May-76','21-Jan-01',100007,32000,'Bangalore');
INSERT INTO staff_master 
VALUES(100006,'Allen',103,30,'22-Jan-80','23-Apr-01',100005,42000,'Chennai');


INSERT INTO staff_master 
VALUES(100007,'Smith',103,20,'19-Jul-73','12-Mar-02',100005,62000,'Mumbai');
INSERT INTO staff_master 
VALUES(100008,'Raviraj',102,40,'17-Jun-80','11-Jan-03',100006,18000,'Bangalore');
INSERT INTO staff_master
VALUES(100009,'Rahul',102,20,'16-Jan-78','11-Dec-03',100006,22000,'Hyderabad');
INSERT INTO staff_master 
VALUES(100010,'Ram',103,30,'17-Jan-79','17-Jan-02',100007,32000,'Bangalore');
--Book Masters
DROP TABLE BOOK_MASTER CASCADE CONSTRAINTS;
DROP TABLE BOOK_MASTERs CASCADE CONSTRAINTS;
CREATE TABLE Book_Master(
Book_code NUMBER(10) PRIMARY KEY,
Book_name VARCHAR2(50) NOT NULL,
Book_pub_year NUMBER,
Book_pub_author VARCHAR2 (50) NOT NULL);


INSERT INTO book_master VALUES(10000001,'Let Us C++',2000,'Yashavant Kanetkar');

INSERT INTO book_master VALUES(10000002,'Mastersing VC++',2005,'P.J Allen');

INSERT INTO book_master VALUES(10000003,'JAVA Complete Reference',2004,'H.Schild');

INSERT INTO book_master VALUES(10000004,'J2EE Complete Reference',2000,'H. Schild');

INSERT INTO book_master VALUES(10000005,'Relational DBMS',2000,'B.C. Desai');

INSERT INTO book_master VALUES(10000006,'Let Us C',2000, 'Yashavant Kanetkar');

INSERT INTO book_master VALUES(10000007,'Intoduction To Algorithams',2001,'Cormen');

INSERT INTO book_master VALUES(10000008,'Computer Networks',2000,'Tanenbaum');

INSERT INTO book_master VALUES(10000009,'Introduction to O/S',2001,'Millan');

--Book Transactions
DROP TABLE BOOK_TRANSACTIONS;
CREATE TABLE Book_transactions(
Book_code NUMBER(10) REFERENCES Book_Master(Book_code),
Student_code NUMBER(6) REFERENCES Student_Master(student_code),
Staff_code number(8) REFERENCES Staff_Master(staff_code),
Book_issue_Date date not null,
Book_expected_return_date date not null,
Book_actual_return_date date);

INSERT INTO book_transactions 
VALUES(10000006,1012,NULL,'02-Feb-2011','09-Feb-2011',NULL);

INSERT INTO book_transactions 
VALUES(10000008,NULL,100006,'10-Mar-2011','17-Mar-2011','15-Mar-2011');

INSERT INTO book_transactions 
VALUES(10000009,NULL,100010,'01-Apr-2011','08-Apr-2011','10-Apr-2011');

INSERT INTO book_transactions 
VALUES(10000004,1015,NULL,'12-Feb-2011','19-Feb-2011',NULL);


INSERT INTO book_transactions 
VALUES(10000005,NULL,100007,'14-Mar-2011','21-Mar-2011','21-Mar-2011');

INSERT INTO book_transactions 
VALUES(10000007,NULL,100007,'01-Apr-2011','07-Apr-2011','06-Apr-2011');

INSERT INTO book_transactions 
VALUES(10000007,NULL,100006,'01-Apr-2010','07-Apr-2010','06-Apr-2010');
INSERT INTO book_transactions 
VALUES(10000005,1009,NULL,'31-May-2011','08-JUN-2011','08-JUN-2011');

select * from staff_master;


--1.1


SELECT 
Staff_Name AS s_Name,Design_Code AS d_Code
FROM staff_master
WHERE Staff_sal between 12000 and 25000
AND Hiredate <'01-01-2003';

SELECT
Staff_Code,Staff_Name,Dept_Code
FROM staff_master
WHERE Hiredate <'01-01-2002';

SELECT  * 
FROM staff_master
WHERE Mgr_code is NULL;

select * from Book_Master;

SELECT *
FROM Book_Master
WHERE Book_pub_year between '2001' AND '2004'
OR Book_name LIKE '&';

SELECT Staff_Name
FROM Staff_sal
WHERE Staff_Name LIKE '_';


--2.1


SELECT Staff_Name,Staff_sal,LPAD(Staff_sal,15,'&')
AS LeftPadstaff_sal
FROM staff_master;

SELECT Student_Name,to_char(Student_Dob,'month,dd yyyy')as Student_Dob
FROM Student_Master
WHERE to_char(Student_Dob,'day') like ('%saturday%') or to_char(Student_Dob,'day') like ('%sunday%');

SELECT Staff_Name,round(months_between(sysdate,Hiredate))as Months_Worked
FROM staff_master
ORDER BY Months_Worked desc;

SELECT Staff_Code,Staff_Name,Design_Code,Dept_Code,Staff_dob,Hiredate,Mgr_code,Staff_sal,Staff_address
FROM staff_master
WHERE to_char(Hiredate,'dd') between 1 AND 15 AND to_char(Hiredate,'mm') LIKE '%december%';

SELECT Staff_Name,Staff_sal,
CASE 
WHEN Staff_sal>=50000 then 'A'
WHEN Staff_sal<50000 and Staff_sal>=25000 then 'B'
WHEN Staff_sal<25000 and Staff_sal>=10000 then 'C'
else 'D'
END Grade
FROM staff_master;

SELECT Staff_Name,Hiredate,
to_char(Hiredate,'day') AS DAY
FROM staff_master
order by to_char(hiredate,'day')desc;

SELECT INSTR('Mississippi','i',2,3) FROM DUAL;

 

SELECT NEXT_DAY(LAST_DAY(SYSDATE)-INTERVAL '7' DAY,'FRIDAY') AS PAY_DATE FROM DUAL; 
 
SELECT STUDENT_CODE,STUDENT_NAME,DECODE(DEPT_CODE,20,'ELECTRICALS',30,'ELECTRONICS','OTHERS') DEPARTMENT_NAME FROM STUDENT_MASTER;

 

//Excercise 2.2 Group Functions

 

select MIN(Staff_sal)MINIMUM,MAX(Staff_sal)AS MAXIMUM,SUM(Staff_sal)AS TOTAL,ROUND(AVG(Staff_sal))  AS AVERAGE FROM staff_Master GROUP BY DEPT_CODE;

 

SELECT DEPT_CODE, COUNT(MGR_CODE) AS "Total Number of Managers" FROM  staff_Master GROUP BY DEPT_CODE;

 

SELECT  DEPTNO,SUM(SAL) FROM EMP WHERE MGR IS NULL GROUP BY DEPTNO
HAVING SUM(SAL)>20000;

 

//ESCERSICE 3.1 Joins and Subqueries
1//
SELECT S.STAFF_NAME,
  D.DEPT_CODE,
  D.DEPT_NAME,
  S.STAFF_SAL
FROM STAFF_MASTER S,
  DEPARTMENT_MASTER D
WHERE S.DEPT_CODE=D.DEPT_CODE AND Staff_sal>20000;

 

2//
Display Staff Code, Staff Name, Department Name, and his manager�s number and name. Label the columns Staff#, Staff, Mgr#, Manager

 

3//
SELECT S.STAFF_CODE AS STAFF#,
    S.STAFF_NAME AS STAFF,
  D.DEPT_NAME,
  E.MGR AS MGR#,
  E.JOB AS MANAGER
FROM STAFF_MASTER S,
  DEPARTMENT_MASTER D, EMP E
WHERE S.DEPT_CODE=D.DEPT_CODE AND E.DEPTNO = D.DEPT_CODE;

 

4//
SELECT S.Student_Code,
S.Student_Name,
B.Book_code ,
B.Book_name
FROM 
Book_transactions BT,
Student_Master S,
book_master B
WHERE BT.Student_Code=S.Student_Code AND BT.BOOK_CODE=B.BOOK_CODE AND BT.Book_expected_return_date=SYSDATE;

 

5//
SELECT S.STAFF_CODE,
S.STAFF_NAME,
D.DEPT_NAME,
F.DESIGN_NAME,
E.BOOK_NAME,
H.BOOK_ISSUE_DATE 
FROM 
STAFF_MASTER S,
DEPARTMENT_MASTER D,
Designation_Master F,
BOOK_MASTER E,
Book_transactions H
WHERE 
MONTHS_BETWEEN(TO_CHAR(H.BOOK_ISSUE_DATE,'MM'),
TO_CHAR(SYSDATE,'MM'))<1;

 

6//
SELECT
s.staff_code,s.staff_name,d.design_name,de.dept_name,b.book_code,b.book_name,b.book_pub_author,round((sysdate-bo.Book_expected_return_date))*5 as fine
from 
STAFF_MASTER s,Designation_Master d,
Department_Master de,Book_Master b,
Book_Transactions bo
where s.DEPT_CODE=de.DEPT_CODE and b.BOOK_CODe=bo.BOOK_CODE and s.DESIGN_CODE=d.DESIGN_CODE;

 

7//
SELECT  S.Staff_Code, 
S.Staff_Name,
S.Staff_sal
FROM
Department_Master D,
staff_Master S,
EMP E
WHERE 
S.DEPT_CODE = D.DEPT_CODE AND E.DEPTNO = D.DEPT_CODE 
AND S.STAFF_SAL< ALL(SELECT ROUND(AVG(SAL)) FROM EMP GROUP BY DEPTNO);

 


SELECT Staff_Code, Staff_Name,STAFF_SAL  FROM STAFF_MASTER WHERE STAFF_SAL<(SELECT AVG(STAFF_SAL) FROM STAFF_MASTER);

 

SELECT Book_pub_author,Book_name FROM BOOK_MASTER WHERE COUNT(Book_pub_author)>1;

 

8//
SELECT 
S.Staff_Code,
S.Staff_NAME,
D.DEPT_NAME
FROM
STAFF_MASTER S,
BOOK_TRANSACTIONS B, 
Department_Master D
WHERE
D.DEPT_CODE = S.DEPT_CODE AND B.STAFF_CODE = S.STAFF_CODE AND B.STAFF_CODE IN (SELECT Staff_Code FROM STAFF_TRANSACTIONS
GROUP BY S.STAFF_CODE HAVING COUNT(*)>1);

 

select sm.staff_code,sm.staff_name,dm.dept_name
from STAFF_MASTER sm,DEPARTMENT_MASTER dm,BOOK_TRANSACTIONS bt
where sm.DEPT_CODE = dm.DEPT_CODE and sm.STAFF_CODE = bt.STAFF_CODE and bt.STAFF_CODE in (select staff_code from book_transactions group by staff_code
having count(*)>1) ;

 


9//
SELECT 
S.Student_Code,
S.Student_Name
D.DEPT_NAME
FROM
Department_Master D


//Exercise 4

 

1//
create table customer
    (
    customerid number(5),
    cust_name varchar2(20),
    Address1 varchar2(30),
    Address2 varchar2(30)
    );
  
 2//
 Alter table customer rename column cust_name to customername;
 Alter table customer modify customername  varchar2(30) Not Null;
 
 3//
 Alter table customer add Gender varchar2(1);
 Alter table customer add Age Number(3);
 Alter table customer add phoneNo(10);
 
 4//
 insert into cust_table(&Customerid,'&cust_Name','&Address1','&Address2','&Gender',&Age,&phoneNo);
     
 5//
 Alter table cust_table add constraints Custid_prim PRIMARY KEY (customerid);
 
 6//
 
 7//
 Alter table cust_table drop PRIMARY KEY custid_prim;
 
 8//
 Alter table cust_table add constraints Custid_prim PRIMARY KEY (customerid);
 
 9//
Alter table cust_table drop PRIMARY KEY custid_prim;
Insert into cust_table(1002, Becker, #114 New York, #114 New york , M, 45,431525, 15000.50);
Insert into cust_table(1003, Nanapatekar, #115 India, #115 India , M, 45, 431525,20000.50);
 
 10//
 TRUNCATE table cust_table;
 
 11//
 Alter table add e_mail varchar2(30);
 
 12//
 Alter table cust_table DROP e_mail;
 
 13//
 create table Suppliers as select(customerid as suppid,customername as sname,adddress1 as addr1,address2 as     addr2,phoneno as contactno) from cust_table;
 
14//
Drop table Suppliers;
create table customermaster(customerid(10) primary key(custid_pk),customername varchar2(30),Address1     varchar2    (30),Address2 varchar2(30),Gender varchar2(1),Age number(3),phoneno number(10));
 
15//
Create table Accoutnmaster(customerid number(5),Accountnumber number(10) primary key(acno),accounttype char    (3),ledgerbalance number(10) Not Null);
Create sequence seq_ano
        MINVALUE 101
        MAXVALUE 10000
        START WITH 101
        INCREMENT BY 1
        CACHE 101;
 
16//

 

Alter table Accountmaster ADD constraint ass_fk FOREIGN KEY(customerid) REFERENCES customermaster(customerid);
 
17//

 

Insert into customermaster values(1000, Allen, #115 Chicago, #115 Chicago, M, 25, 7878776);
Insert into customermaster values(1001, George, #116 France, #116 France, M, 25, 4345240;
Insert into customermaster values(1002, Becker, #114 New York, #114 New York, M, 45, 4315250;
 
18//

 

alter table Accountmaster add constraint ck_ac check(accountype='NRI' or accountype='IND');
 
19//
 
alter table Accountmaster add constraint     Balance_check(ledger balance > 5000);
 
20//
Modify the AccountsMaster table such that if Customer is deleted from Customer table then all his details should be             deleted from AccountsMaster table. 
Delete from Accountmaster,customertable where customerid = 1001
 
 
21//
Create Backup copy for the AccountsMaster table with the name �AccountDetails�. 
Create table accountdetails as select * from Accountmaster;
 
22//
Create a view �Acc_view� with columns Customerld, CustomerName, AccountNumber, AccountType, and LedgerBalance from         AccountsMaster. In the view Acc_view,     the column names should be CustomerCode, AccountHolderName, AccountNumber, Type, and         Balance for the respective columns from AccountsMaster table. 
CREATE VIEW Acc_view AS SELECT(Customerid,Customername,Accountnumber,AccountType,ledgerBalance)
    from AccountMaster;
 
23//
Create a view on AccountsMaster table with name vAccs_Dtls. This view should list all customers whose AccountType is �IND�         and their balance amount should not be less than 10000. Using this view any DML operation should not violate the view         conditions. 
CREATE VIEW vAccs_Dtls AS SELECT     Accounttype,ledgerbalance from Accountmaster where     accounttype = 'IND' and         ledgerbalance < 10000;
 
24//
 
25//
Create a Sequence with the name Seq_Dept on Deptno column of Department_Masters table. It should start from 40 and stop at         200. Increment parameter for the sequence Seq_Dept should be in step of 10.
CREATE sequence SEQ_DEPTt minvalue 40 start with 40
    increment by 10 cache 40;
 
26//
Insert three sample rows by using the above sequence in Department_Masters table.
create table departmentmaster(deptno number(50),Dname varchar2(25),location varchar2(25));
insert into departmentmaster  values(seq_dept.NEXTVAL,'MARKETING','NEW DELHI');
insert into departmentmaster  values(seq_dept.NEXTVAL,'SALES','chennai');
insert into departmentmaster  values(seq_dept.NEXTVAL,'RESEARCH','BOSTON');
 
27//
DROP sequence seq_dept;
 
28//
CREATE INDEX no_name on emp(empno);
select * from emp;
29//
create SYNONYM synemp for emp;
 
30//
select * from synemp;
 
 
 
 //Excersice 5
 
 
//Exercise 5

 

1//
Create table employee as select * from emp where 1=3;
desc employee;
select * from employee
 
2//
select * from employee;

 

3//
update table employee set job=(select job from employee where empno=7788),deptno=(select deptno from employee where empno=7788) where empno=7698;
 
4//
delete from employee where departmentname like '%sales%';
 
5//
update table employee set deptno=(select deptno from employee where deptno=7788) where deptno=7698;
 
6//
 
insert into emp (empno,'ename','job',mgr,'hiredate',sal,comm,deptno) values (1000,Allen, Clerk,1001,12-jan-01, 3000, 2,10);
insert into emp (empno,'ename','job',mgr,'hiredate',sal,comm,deptno) values (1001,George, analyst, null, 08 Sep 92, 5000,0, 10);
insert into emp (empno,'ename','job',mgr,'hiredate',sal,comm,deptno) values (1002, Becker, Manager, 1000, 4 Nov 92, 2800,4, 20);
insert into emp (empno,'ename','job',mgr,'hiredate',sal,comm,deptno) values (1003, 'Bill', Clerk, 1002, 4 Nov 92,3000, 0, 20);
 
 
//Excercise 6
  Transaction Control Language Statements
  
  
1//    
Insert rows with the following data into the Customer table.
 
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values ( 6000, John, #115 Chicago, #115 Chicago, M, 25, 7878776, 10000 );
 
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values (    6001, Jack, #116 France, #116 France, M, 25, 434524, 20000  );
 
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values (    6002, James, #114 New York, #114 New York, M, 45, 431525, 15000.50);
 
 
2//
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values ( 6000, John, #115 Chicago, #115 Chicago, M, 25, 7878776, 10000 );
 
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values (    6001, Jack, #116 France, #116 France, M, 25, 434524, 20000  );
 
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values (    6002, James, #114 New York, #114 New York, M, 45, 431525, 15000.50);
 
 savepoint p1;
 
 
3//
insert into customermaster (customerid,'customername','address1','address2','gender',age,'phoneno) values (    6003, John, #114 Chicago, #114 Chicago, M, 45, 439525, 19000.60);
 
4// 
rollback p1;